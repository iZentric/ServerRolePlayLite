"""Guard against marketing a benchmark loser as a new engine or RP plans as live."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "site"))
import engine_results  # noqa: E402


class SiteClaimsTest(unittest.TestCase):
    def test_winner_requires_matching_player_and_release_provenance(self):
        page = engine_results.panel()
        self.assertIn(engine_results.JAR_URL, page)
        self.assertIn("96f824793ab3a685a390d82305202403ea8cbe5c011a1c79ce0ec024a4d7789c", page)
        self.assertIn("identic byte-cu-byte", page)
        self.assertIn("nu e declarat mai rapid", page)
        self.assertNotIn("🏆 Cel mai bun rezultat", page)
        self.assertIn("nu este upgrade demonstrat", page)
        self.assertIn("Arclight cu pack-ul complet", page)
        self.assertIn("Mist pe Java 11", page)

    def test_native_result_shows_both_runs_and_not_historical_savings(self):
        page = engine_results.panel()
        self.assertIn("Diferența reală: CUANTIC vs CatServer oficial", page)
        self.assertIn("2205,1 / 2452,0 MiB", page)
        self.assertIn("2185,6 / 2475,6 MiB", page)
        self.assertIn("nu demonstrează FPS ori consum în oraș", page)
        self.assertIn("ENGINE-NATIVE-RESULT.md", page)
        self.assertIn("Nu se confirmă o economie de 171 MB", page)
        self.assertIn("Patch REAL în JAR — verdict: RESPINS", page)
        self.assertIn("4,41 / 3,72 s", page)
        self.assertIn("2202,1 / 2528,9 MiB", page)
        self.assertIn("nu trec: RAM RSS, CPU stabil, p95 MSPT, Done intern", page)
        self.assertIn("Nu am lansat JAR-ul", page)
        self.assertIn("Test cu jucători simulați — NU validat încă", page)
        self.assertIn("la <b>0/25</b>", page)
        self.assertIn("ENGINE-FAKEPLAYERS-RESULT.md", page)
        with patch.object(engine_results, "result", return_value={}):
            incomplete = engine_results.panel()
        self.assertNotIn("2205,1 / 2452,0 MiB", incomplete)
        self.assertIn("nu are încă un rezultat complet verificat", incomplete)

    def test_plain_language_choice_compares_full_pack_without_inventing_winner(self):
        page = engine_results.panel()
        self.assertIn('id="alegere"', page)
        for name in ("CUANTIC live", "CatServer oficial", "CUANTIC experimental",
                     "Arclight", "Mist", "Paper / Forge simplu", "Mohist / Magma"):
            self.assertIn(name, page)
        self.assertIn("nu e demonstrat că pierde", page)
        self.assertIn("Nu îl instala", page)
        self.assertIn("De ce să alegi CUANTIC, atunci?", page)
        self.assertIn("Clientul are adresa salvată", page)
        self.assertIn("Nu este FPS-ul clientului".lower(), page.lower())
        self.assertIn("ENGINE-FAKEPLAYERS-RESULT.md", page)
        self.assertIn("ENGINE-PERFORMANCE-2026-10-12.md", page)
        self.assertIn("ENGINE-PACK-AUDIT.md", page)
        self.assertNotIn("CUANTIC este mai rapid decât oficialul", page)
        with patch.object(engine_results, "result", return_value={}):
            missing = engine_results.panel()
        self.assertIn("Comparația cu pack identic nu este verificată complet", missing)
        self.assertIn("Testul complet al patch-ului este incomplet", missing)
        self.assertNotIn("<b>DA</b> · 36/14", missing)

    def test_missing_proof_cannot_advertise_direct_jar(self):
        with patch.object(engine_results, "result", return_value={}):
            page = engine_results.panel()
        self.assertNotIn(engine_results.JAR_URL, page)
        self.assertIn("nu afișăm un câștigător nou neverificat", page)

    def test_strategy_is_labeled_future_work(self):
        page = engine_results.strategy_panel()
        self.assertIn('id="viziune"', page)
        self.assertIn("survival + mafii", page)
        self.assertIn("nu funcții declarate deja lansate", page)
        self.assertIn("STRATEGIE-ROLEPLAY-SURVIVAL.md", page)
        self.assertIn("OptiFine + modurile normale", page)
        self.assertIn("INCIDENT-2026-10-11-STATUS.md", page)

    def test_tunnel_config_requires_external_credential(self):
        import re
        for name in ("cuantic-live.sh", "ensure-up.sh", "frps-install.sh", "up.sh"):
            source = (ROOT / "scripts" / name).read_text()
            self.assertNotRegex(source, r'auth\.token = \\?"(?!%s)[^"\\]+\\?"', name)
        self.assertIn("FRP_AUTH_TOKEN", (ROOT / "scripts" / "frps-install.sh").read_text())

    def test_built_page_contains_benchmark_download_and_strategy(self):
        page = (ROOT / "site" / "index.html").read_text(encoding="utf-8")
        self.assertIn(engine_results.JAR_URL, page)
        self.assertIn("BENCHMARK-MOTOARE-CUANTIC-2026-10-12.md", page)
        self.assertIn('id="viziune"', page)
        self.assertNotIn("merge și pe cartof, fără lag", page)
        self.assertNotIn("32 de moduri si 15 pluginuri", page)
        # These two minima had missing source logs and were never a paired A/B.
        self.assertNotIn("2643 MB · boot 11.521s", page)
        self.assertNotIn("2814 MB · boot 11.062s", page)
        self.assertIn("90.7 MB", page)
        self.assertIn("51.1 MB", page)
        self.assertNotIn("(0 MB)", page)


if __name__ == "__main__":
    unittest.main()
